const register = async (req, res) => {
    // Registration logic here
};

const login = async (req, res) => {
    // Login logic here
};

module.exports = {
    register,
    login
};
